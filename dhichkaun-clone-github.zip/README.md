# Dhichkaun Clone

A playful landing page built with **Next.js + Tailwind CSS + Framer Motion**.

## 🚀 Getting Started

### Run locally
```bash
npm install
npm run dev
```

### Deploy on Vercel
1. Push this project to a GitHub repository.
2. Go to [Vercel](https://vercel.com).
3. Import the GitHub repo and click **Deploy**.

That's it 🎉
